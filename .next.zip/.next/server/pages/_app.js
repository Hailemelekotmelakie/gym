(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 168:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "nav_container___1T8j",
	"linksContainer": "nav_linksContainer__U1frL",
	"links": "nav_links__UGUiD",
	"navSelect": "nav_navSelect__FfQ6_",
	"nightMode": "nav_nightMode__ja7Zl",
	"checkbox": "nav_checkbox__P2o82",
	"label": "nav_label__YlOIb",
	"ball": "nav_ball__mjxSq",
	"link": "nav_link__9RdN0",
	"menu": "nav_menu__hx2HV",
	"all": "nav_all__LDK76",
	"menuLine": "nav_menuLine__T5Qdj",
	"upline": "nav_upline__Tru9l",
	"downline": "nav_downline__peNgq"
};


/***/ }),

/***/ 317:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(844);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(689);
;// CONCATENATED MODULE: ./src/lang/am/navs.js
/* harmony default export */ const am_navs = ({
    home: "መነሻ ገጽ",
    about: "ስለ እኛ",
    contact: "እኛን ያግኙን",
    map: "ካርታ"
});

;// CONCATENATED MODULE: ./src/lang/en/navs.js
/* harmony default export */ const en_navs = ({
    home: "Home",
    about: "About",
    contact: "Contact",
    map: "Map"
});

;// CONCATENATED MODULE: ./src/lang/aw/navs.js
/* harmony default export */ const aw_navs = ({
    home: "ጉሽጺ ጌጽ",
    about: "እኖጂ አይ",
    contact: "ታምትኚ",
    map: "ካርቲ"
});

// EXTERNAL MODULE: ./src/useContext/context.js
var context = __webpack_require__(124);
// EXTERNAL MODULE: ./src/shared/nav.module.css
var nav_module = __webpack_require__(168);
var nav_module_default = /*#__PURE__*/__webpack_require__.n(nav_module);
;// CONCATENATED MODULE: ./src/shared/nav.js







function Nav() {
    const { language , setLanguage  } = (0,external_react_.useContext)(context/* LanguageContext */.A);
    const l = language === "am" ? am_navs : language === "aw" ? aw_navs : en_navs;
    const [theme, setTheme] = (0,external_react_.useState)("light");
    const [isHeaderOn, setHeaderOn] = (0,external_react_.useState)(false);
    const navs = [
        {
            name: l.home,
            link: "home"
        },
        {
            name: l.about,
            link: "about"
        },
        {
            name: l.map,
            link: "map"
        }
    ];
    (0,external_react_.useEffect)(()=>{
        document.getElementById("head").style.right = isHeaderOn ? "0%" : "200%";
    }, [
        isHeaderOn
    ]);
    (0,external_react_.useEffect)(()=>{
        setLanguage(localStorage.getItem("Language"));
    });
    (0,external_react_.useEffect)(()=>{
        let root = document.querySelector(":root");
        if (localStorage.getItem("theme") == undefined) {
            localStorage.setItem("theme", "light");
        }
        if (localStorage.getItem("theme") == "dark") {
            root.classList.remove("light");
            root.classList.add("dark");
            document.getElementById("checkbox").checked = true;
        } else {
            root.classList.remove("dark");
            root.classList.add("light");
            document.getElementById("checkbox").checked = false;
        }
    }, [
        theme
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: (nav_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: (nav_module_default()).menu,
                onClick: ()=>{
                    setHeaderOn(!isHeaderOn);
                },
                children: !isHeaderOn ? /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: (nav_module_default()).menuLine
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: (nav_module_default()).menuLine
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: (nav_module_default()).menuLine
                        })
                    ]
                }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: (nav_module_default()).upline
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: (nav_module_default()).downline
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                id: "head",
                className: (nav_module_default()).linksContainer,
                children: [
                    navs.map((link, i)=>/*#__PURE__*/ jsx_runtime.jsx("a", {
                            style: {
                                textDecoration: "none"
                            },
                            href: `#${link.link}`,
                            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: (nav_module_default()).links,
                                children: link.name
                            })
                        }, i)),
                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("select", {
                            className: (nav_module_default()).navSelect,
                            value: language,
                            onChange: (e)=>{
                                localStorage.setItem("Language", e.target.value);
                                setLanguage(e.target.value);
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("option", {
                                    value: "en",
                                    children: "Eng "
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("option", {
                                    value: "am",
                                    children: " አማርኛ "
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("option", {
                                    value: "aw",
                                    children: " አዊ "
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        style: {
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                            gap: 10
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                className: [
                                    (nav_module_default()).links + " " + (nav_module_default()).nightMode
                                ],
                                children: " Night mode"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("input", {
                                type: "checkbox",
                                onChange: ()=>{
                                    let root = document.querySelector(":root");
                                    if (localStorage.getItem("theme") == "dark") {
                                        root.classList.remove("dark");
                                        root.classList.add("light");
                                        setTheme("light");
                                        localStorage.setItem("theme", "light");
                                    } else {
                                        root.classList.remove("light");
                                        root.classList.add("dark");
                                        setTheme("dark");
                                        localStorage.setItem("theme", "dark");
                                    }
                                },
                                className: (nav_module_default()).checkbox,
                                id: "checkbox"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("label", {
                                for: "checkbox",
                                className: (nav_module_default()).label,
                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: (nav_module_default()).ball
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
;// CONCATENATED MODULE: ./src/pages/_app.js





function Home({ Component , pageProps  }) {
    const [language, setLanguage] = (0,external_react_.useState)("am");
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(context/* LanguageContext.Provider */.A.Provider, {
            value: {
                language,
                setLanguage
            },
            children: [
                /*#__PURE__*/ jsx_runtime.jsx(Nav, {}),
                /*#__PURE__*/ jsx_runtime.jsx(Component, {
                    ...pageProps
                })
            ]
        })
    });
}


/***/ }),

/***/ 124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ LanguageContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const LanguageContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});


/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 38:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [844], () => (__webpack_exec__(317)));
module.exports = __webpack_exports__;

})();